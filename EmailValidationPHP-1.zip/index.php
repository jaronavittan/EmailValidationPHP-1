<?php
    error_reporting(0);
 if (isset($_POST['submit'])) {
    $email = $_POST['Email'];

   if(empty($email)) {
      $err = "Please Enter Email";
   }
 }

?>


<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>

     <div class="container m-5">

     <h1 class="text-white text-center bg-warning rounded shadow">Email validation in PHP</h1>

     <form class ="form-group mt-5" method="post">

     <label>Enter Email Addess:-</label><span><?php echo $err; ?></span>

     <input type="Email" name="Email" value="" placeholder="Enter Email" class="form-control" autocomplete="off"><br>

     <input type="submit" name="submit" value="Submit" class="btn btn-warning shadow">

     </form>  


    
  </body>
</html>